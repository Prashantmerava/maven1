# Time Tracker

Java (Maven) application for tracking time on the job

## Purpose

Simple Java-app using Maven.

## Building

Standard maven targets for building.

Requirements:

* JDK 17+
* Maven 3.8+

```bash
mvn clean install
```
